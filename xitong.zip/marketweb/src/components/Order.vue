<template>
	
</template>

<script type="text/ecmascript-6">
export default {
  name: 'Order',
  data () {
    return {
    }
  }
}
</script>
<style scoped lang='stylus' rel="stylesheet/stylus">
</style>
