<template>
<div class="footer">
  这是底部数据
</div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'Footer',
  data () {
    return {
    }
  }
}
</script>
<style scoped lang='stylus' rel="stylesheet/stylus">
</style>
